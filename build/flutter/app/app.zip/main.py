import flet as ft

from tabs import tabs
from logica.manejo_cliente import ManejoCliente
from logica.manejo_servicio import ManejoServicio
from faker import Faker


# from ui.cliente_ui import cargar_clientes_en_tabla
majeo = ManejoCliente()
servicio = ManejoServicio()
fake = Faker()


def main(page: ft.Page):
    # Configuración de la ventana
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.title = "Taller Mecánico App"
    page.window_height = 600
    page.window_resizable = True  # Permite redimensionar
    page.theme_mode = ft.ThemeMode.DARK
    page.add(tabs)
    page.update()

    # for i in range(20):
    #     servicio.guardar_servicio(fake.name(), fake.pricetag())


print("recargado")

if __name__ == "__main__":
    ft.app(target=main, assets_dir="assets")
