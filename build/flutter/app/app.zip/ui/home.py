import flet as ft
from flet.core.border_radius import horizontal

from logica.manejo_cliente import ManejoCliente


manego_cliente = ManejoCliente()

container_style = {
    # "expand": True,
    # "border": ft.border.all(1, "red"),
    "border_radius": 10,
    "padding": 20,
}


class TotalData(ft.Container):
    def __init__(self):
        super().__init__(**container_style, border=ft.border.all(1, "red"), expand=True)
        self.content = ft.Row(
            controls=[
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text(
                                        "Clientes de la Semana",
                                        text_align=ft.alignment.center,
                                    ),
                                    ft.Text(
                                        value=str(len(manego_cliente.cargar_clientes()))
                                    ),
                                ],
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                alignment=ft.alignment.center,
                            ),
                            ft.Icon("Person"),
                        ],
                    ),
                    padding=10,
                    border=ft.border.all(1, "green"),
                ),
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Clientes Totales"),
                                    ft.Text(
                                        value=str(len(manego_cliente.cargar_clientes()))
                                    ),
                                ],
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            ),
                            ft.Icon("Person"),
                        ],
                    ),
                    padding=10,
                    border=ft.border.all(1, "green"),
                ),
                ft.Container(
                    content=ft.Row(
                        controls=[
                            ft.Column(
                                controls=[
                                    ft.Text("Clientes Totales"),
                                    ft.Text(
                                        value=str(len(manego_cliente.cargar_clientes()))
                                    ),
                                ],
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            ),
                            ft.Icon("Person"),
                        ],
                    ),
                    padding=10,
                    border=ft.border.all(1, "green"),
                ),
            ],
            expand=True,
        )


class IngresosData(ft.Container):
    def __init__(self):
        super().__init__(expand=True)
        self.content = ft.Row(
            controls=[
                ft.Container(content=ft.Column([ft.Text("Ingresos del mes")])),
                ft.Container(content=ft.Column([ft.Text("Pagos del mes")])),
            ]
        )


class PagosData(ft.Container):
    def __init__(self):
        super().__init__(expand=True)
        self.content = ft.Row(
            controls=[
                ft.Container(content=ft.Column([ft.Text("Ingresos del mes")])),
                ft.Container(content=ft.Column([ft.Text("Pagos del mes")])),
            ]
        )


container_cliente = TotalData()
container_pago = IngresosData()


class HomeUiState(ft.Container):
    def __init__(self):
        super().__init__(**container_style, expand=True)
        self.content = ft.Column(
            controls=[ft.Row([container_cliente]), ft.Row([container_pago])]
        )


home = HomeUiState()
